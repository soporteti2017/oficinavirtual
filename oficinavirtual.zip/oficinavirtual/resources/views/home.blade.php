@extends('layouts.app')

@section('content')

    @include('layouts/menu')

@endsection
