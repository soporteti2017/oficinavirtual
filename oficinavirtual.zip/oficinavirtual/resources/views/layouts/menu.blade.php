					<div class="row">
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <a href="{{ route('usuarios.menu') }}">
                                    <button type="button" class="btn btn-primary btn-lg btn-block">USUARIOS</button>
                                </a>     
                            </div>
                            <div class="col-md-3">
                                <a href="{{ route('clientes.menu') }}">
                                    <button type="button" class="btn btn-primary btn-lg btn-block">CLIENTES</button>
                                </a>    
                            </div>
                            <div class="col-md-3">
                                <a href="{{ route('cuentas.menu') }}">
                                    <button type="button" class="btn btn-primary btn-lg btn-block">CUENTAS</button>
                                </a>    
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">SERVICIO</button>
                            </div>  
                        </div>
                    </div> 
                    <br>
                    <div class="row">  
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">INVENTARIO</button> 
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">CONTABILIDAD</button>
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">COMPRAS</button>
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">ARCHIVOS</button>
                            </div>  
                        </div>
                    </div>    
                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-1"></div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">RECURSOS</button> 
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">COBRANZA</button>
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">ACTIVOS</button>
                            </div>
                        </div>
                    </div> 
                    <br>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-3"></div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">CALL CENTER</button> 
                            </div>
                            <div class="col-md-3">
                                <button type="button" class="btn btn-primary btn-lg btn-block">GESTION</button>
                            </div>
                        </div>
                    </div>  