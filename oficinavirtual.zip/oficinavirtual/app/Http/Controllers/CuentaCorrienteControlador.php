<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Contrato;
use App\Cliente;
use App\PremiumCaja;

class CuentaCorrienteControlador extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('intranet.cuenta_corriente.saldo')->with('ver', 'saldos');
    }


    public function general(){

        return view('intranet.cuenta_corriente.general')->with('ver', 'general');
    }

    public function consulta(Request $request){
        $contratos = Contrato::getcontrato($request->id);
        $cliente = Cliente::getcliente($contratos);
        $contratos->each(function($contratos){
            $contratos->estado_conexion;
            $contratos->direccion->calle->poblacion;
        });
        //dd($contratos);
        return view('intranet.cuenta_corriente.vercontrato')->with('ver', 'general')
                                                        ->with('contratos' , $contratos)
                                                        ->with('cliente', $cliente);
    }

    public function verdetalles(Request $request){
        if($request->consulta == 0){
            $premiums  = PremiumCaja::getpremium($request->contrato_id);
            $premiums->each(function($premiums){
            $premiums->contrato;
            $premiums->estado_stb;
            });
            return view('intranet.cuenta_corriente.vercontratodetalle')->with('ver', 'general')
                                                                        ->with('contrato_id', $request->contrato_id)
                                                                        ->with('num_contrato', $request->correlativo_manual)
                                                                        ->with('estado_cone', $request->estado_conexion)
                                                                        ->with('fecha_contrato', $request->fecha_contrato)
                                                                        ->with('fecha_estado', $request->fecha_estado)
                                                                        ->with('nombre_abonado', $request->nombre_abonado)
                                                                        ->with('premiums', $premiums);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
