<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contrato extends Model
{
    protected $table = "contratos";

    protected $fillable = ['id', 'correlativo_manual', 'fecha', 'id_plan', 'fecha_inicio_pago', 'dia_pago', 
    						'fecha_conexion', 'id_estado_conexion', 'fecha_estado_conexion', 'observacion', 'direccion_id'];

   public function estado_conexion(){
    	return $this->belongsTo('App\Estado_conexion');
    }

    public function direccion(){
    	return $this->belongsTo('App\Direccion');
    }  						

   public static function getcontrato($correlativo){
      return Contrato::where('id', '=', $correlativo)
      						->get();
    }
}
