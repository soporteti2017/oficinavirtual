<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'users';
    protected $fillable = [
        'usuario', 'password', 'rut', 'nombre', 
        'administrador', 'boleta', 'vigente', 'boleta1', 
        'boleta2', 'boleta3', 'root', 'externo', 'caja', 
        'boleta4', 'email', 'tipo_usuario_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function scopeSearch($query, $name){
        return $query->where('usuario', 'LIKE', "%$name%");
    }
}
