<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Orden_trabajo extends Model
{
    protected $table = "ordenes_trabajos";

    protected $fillable = ['fecha_recepcion', 'nula', 'tipo_ot_id', 'contrato_id', 'tipo_reclamo_id', 'estado_ot_id', 
    						'usuario_id'];

   public function contrato(){
    	return $this->belongsTo('App\Contrato');
    }

    public function tipo_ot(){
    	return $this->belongsTo('App\Tipo_OT');
    } 

    public function tipo_reclamo(){
    	return $this->belongsTo('App\tipo_reclamo');
    } 

    public function tipo_ot(){
    	return $this->belongsTo('App\Tipo_OT');
    }
}
