<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cuenta_corriente extends Model
{
    protected $table = "cuentas_corrientes";

    protected $fillable = ['movimiento', 'fecha_documento', 'documento', 'fecha_vencimiento', 'valor', 'signo', 'correlativo_abonado'];

    public function tipo_plan(){
    	return $this->belongsTo('App\Tipo_plan', 'id_tipo_plan');
    }

    public function scopeSearch($query, $name){
        return $query->where('descripcion', 'LIKE', "%$name%");
    }
}
