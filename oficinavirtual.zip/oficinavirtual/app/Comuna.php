<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comuna extends Model
{
    protected $table = "sectores";
    protected $fillable = ['sector', 'comuna_id'];

    public function sectores(){
    	return $this->hasMany('App\Sector');
    }


    public function scopeSearch($query, $name)
   {
   		return $query->where('numero','LIKE', "%$name%");
   }
}
