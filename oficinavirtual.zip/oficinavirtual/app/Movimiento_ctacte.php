<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Movimiento_ctatcte extends Model
{
    //
}
