<?php $__env->startSection('titulo', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">

	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		 <div class="col-md-10">	

		 		<div class="panel panel-primary">
				  <div class="panel-heading"><strong>Ingrese número de cliente:</strong> </div>
				  <div class="panel-body">
				    
				  	<?php echo Form::open(['route' => 'cuenta_corriente.consulta', 'method' => 'POST']); ?>

			
						<div class="form-group">
							<?php echo Form::label('id', 'Cliente'); ?>

							<?php echo Form::text('id', null, ['class' => 'form-control', 'placeholder' => 'Ingrese número de cliente', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::submit('Ingresar', ['class' => 'btn btn-primary large']);; ?>

						</div>
					<?php echo Form::close(); ?>	


				  </div>
				</div>
		     	
    	</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>