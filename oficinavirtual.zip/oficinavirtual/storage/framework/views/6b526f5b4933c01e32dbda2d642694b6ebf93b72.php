<?php $__env->startSection('titulo', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		<div class="col-md-10">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><strong><h3>Editar Planes <?php echo $plan->descripcion; ?></h3></strong>
			  </div>
			  <div class="panel-body">
			    	
			  		<?php echo Form::open(['route' => ['planes.update', $plan], 'method' => 'PUT']); ?>

						<div class="form-group">
							<?php echo Form::label('descripcion', 'Nombre Plan'); ?>

							<?php echo Form::text('descripcion', $plan->descripcion, ['class' => 'form-control', 'placeholder' => 'Ingrese Descripción de plan.', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('fecha_inicio', 'Fecha de inicio'); ?>

							<?php echo Form::date('fecha_inicio', $plan->fecha_inicio, ['class' => 'form-control', 'required']);; ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('fecha_fin', 'Fecha fin'); ?>

							<?php echo Form::date('fecha_fin', $plan->fecha_fin, ['class' => 'form-control', 'required']);; ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('meses', 'Meses sin costo'); ?>

							<?php echo Form::text('meses', $plan->meses, ['class' => 'form-control', 'placeholder' => 'Eje: 1', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('id_tipo_plan', 'Tipo de plan'); ?>

							<?php echo Form::select('id_tipo_plan', $tipos_planes, $plan->tipo_plan->id, ['class' => 'form-control', 
							'placeholder' => 'Seleccione una opción', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::submit('Editar', ['class' => 'btn btn-primary large']);; ?>

						</div>

					<?php echo Form::close(); ?>


			  </div>
			</div>
		</div>	
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>