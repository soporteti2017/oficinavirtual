<?php $__env->startSection('titulo', 'Estados de conexiones'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">

	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		 <div class="col-md-10">	

		 	<div class="panel panel-default">

		 		
		        		
		        			<?php echo Form::open(['route' => 'estados_conexiones.index', 'method' => 'GET', 'class' => 'navbar-form pull-right']); ?>

		        				<div class="input-group">
		        					<?php echo Form::text('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Buscar estados...', 'aria-describedby' => 'search']); ?>

		        					 <span class="input-group-addon" id="basic-addon2"><span class="glyphicon glyphicon-search" id="search" aria-hidden="true"></span>
		        					<span></span>
		        				</div>
		        			<?php echo Form::close(); ?>

		        			<hr>
		        		

		        <div class="panel-body">
		        		<div class="table-responsive">
						  <table class="table table-striped">
						    <thead>
						    	<th> DESCRIPCION </th>
						    	<th> ACCION </th>
						    </thead>
						    <tbody>
						    	<?php $__currentLoopData = $estados_conexiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado_conexion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<tr>
							    		<td> <?php echo e($estado_conexion->descripcion); ?> </td>
							    		<td>
							    			<a href="<?php echo e(route('estados_conexiones.destroy', $estado_conexion->id)); ?>" onclick="return confirm('¿Seguro de desea eliminarlo?')" class="btn btn-danger"> <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>  </a>
							    			<a href="<?php echo e(route('estados_conexiones.edit', $estado_conexion->id)); ?>" class="btn btn-warning"> <span class="glyphicon glyphicon-repeat" aria-hidden="true"></span>  </a>
							    		</td>	
							    	</tr>	
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>	
						  </table>
					  	</div>
						  <center>
						  	<a href="<?php echo e(route('estados_conexiones.create')); ?>" class="btn btn-success"> Agregar Nuevo Estado </a> <br>
						  </center>	
					  <br>
					  <center>
					  <?php echo e($estados_conexiones->render()); ?>

					  </center>
		        </div>
		    </div>    	
    	</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>