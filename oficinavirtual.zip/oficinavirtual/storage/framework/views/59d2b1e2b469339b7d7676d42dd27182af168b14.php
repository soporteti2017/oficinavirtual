<?php $__env->startSection('titulo', 'Tipos de pagos'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">

	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		 <div class="col-md-10">	

		 	<div class="panel panel-default">

		 		
		        		
		        			<?php echo Form::open(['route' => 'tipos_pagos.index', 'method' => 'GET', 'class' => 'navbar-form pull-right']); ?>

		        				<div class="input-group">
		        					<?php echo Form::text('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Buscar tipos de pagos...', 'aria-describedby' => 'search']); ?>

		        					 <span class="input-group-addon" id="basic-addon2"><span class="glyphicon glyphicon-search" id="search" aria-hidden="true"></span>
		        					<span></span>
		        				</div>
		        			<?php echo Form::close(); ?>

		        			<hr>
		        		

		        <div class="panel-body">
		        		<div class="table-responsive">
						  <table class="table table-striped">
						    <thead>
						    	<th> DESCRIPCION </th>
						    	<th> ACCION </th>
						    </thead>
						    <tbody>
						    	<?php $__currentLoopData = $tipos_pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<tr>
							    		<td> <?php echo e($tipo_pago->descripcion); ?> </td>
							    		<td>
							    			<a href="<?php echo e(route('tipos_pagos.destroy', $tipo_pago->id)); ?>" onclick="return confirm('¿Seguro de desea eliminarlo?')" class="btn btn-danger"> <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>  </a>
							    			<a href="<?php echo e(route('tipos_pagos.edit', $tipo_pago->id)); ?>" class="btn btn-warning"> <span class="glyphicon glyphicon-repeat" aria-hidden="true"></span>  </a>
							    		</td>	
							    	</tr>	
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>	
						  </table>
					  	</div>
						  <center>
						  	<a href="<?php echo e(route('tipos_pagos.create')); ?>" class="btn btn-success"> Agregar Nuevo Tipo de pago </a> <br>
						  </center>	
					  <br>
					  <center>
					  <?php echo e($tipos_pagos->render()); ?>

					  </center>
		        </div>
		    </div>    	
    	</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>