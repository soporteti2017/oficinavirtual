<?php $__env->startSection('titulo', 'Servicios'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">

	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		 <div class="col-md-10">	

		 	<div class="panel panel-default">

		 		
		        		
		        			<?php echo Form::open(['route' => 'servicios.index', 'method' => 'GET', 'class' => 'navbar-form pull-right']); ?>

		        				<div class="input-group">
		        					<?php echo Form::text('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Buscar servicios...', 'aria-describedby' => 'search']); ?>

		        					 <span class="input-group-addon" id="basic-addon2"><span class="glyphicon glyphicon-search" id="search" aria-hidden="true"></span>
		        					<span></span>
		        				</div>
		        			<?php echo Form::close(); ?>

		        			<hr>
		        		

		        <div class="panel-body">
		        		<div class="table-responsive">
						  <table class="table table-striped">
						    <thead>
						    	<th> ID </th>
						    	<th> DESCRIPCION </th>
						    	<th> VALOR $</th>
						    	<th> UNICA VEZ </th>
						    	<th> ACCION </th>
						    </thead>
						    <tbody>
						    	<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						    		<tr>
						    			<td> <?php echo e($servicio->id); ?> </td>
							    		<td> <?php echo e($servicio->descripcion); ?> </td>
							    		<td> <?php echo e($servicio->valor); ?> </td>
							    		<td> 
							    			<?php if($servicio->unica_vez == 1): ?>
							    				<span class="label label-primary">SI</span>
							    			<?php else: ?>
							    				<span class="label label-success">NO</span>	
							    			<?php endif; ?>
							    		</td>
							    		<td>
							    			<a href="<?php echo e(route('servicios.destroy', $servicio->id)); ?>" onclick="return confirm('¿Seguro de desea eliminarlo?')" class="btn btn-danger"> <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>  </a>
							    			<a href="<?php echo e(route('servicios.edit', $servicio->id)); ?>" class="btn btn-warning"> <span class="glyphicon glyphicon-repeat" aria-hidden="true"></span>  </a>
							    		</td>	
							    	</tr>	
						    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </tbody>	
						  </table>
					  	</div>
						  <center>
						  	<a href="<?php echo e(route('servicios.create')); ?>" class="btn btn-success"> Agregar Nuevo Servicio </a> <br>
						  </center>	
					  <br>
					  <center>
					  <?php echo e($servicios->render()); ?>

					  </center>
		        </div>
		    </div>    	
    	</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>