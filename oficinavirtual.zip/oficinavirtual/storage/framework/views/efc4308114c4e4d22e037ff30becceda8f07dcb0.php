
           <?php if($ver == "clientes"): ?> 

              <ul class="nav nav-stacked nav-collapse">
                <li>
                  <a href="<?php echo e(route('usuarios.index')); ?>">
                    <button type="button" class="btn btn-primary btn-lg btn-block">CLIENTES</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">CONTRATOS</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">PLANES</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">FICHAS</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">AUDITORIA</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">BUSQUEDA</button>
                  </a> 
                </li>
                <li>
                  <a href="\\192.168.1.203:8000/">
                    <button type="button" class="btn btn-primary btn-lg btn-block">VOLVER</button>
                  </a> 
                </li>

              </ul>

           <?php elseif($ver == "usuarios"): ?> 

              <ul class="nav nav-stacked nav-collapse">
                <li>
                  <a href="<?php echo e(route('usuarios.index')); ?>">
                    <button type="button" class="btn btn-primary btn-lg btn-block">USUARIOS</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">CONSULTAR</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">RESTRICCION</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">EXCEPCIONES</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">REPORTES</button>
                  </a> 
                </li>
                <li>
                  <a href="\\192.168.1.203:8000/">
                    <button type="button" class="btn btn-primary btn-lg btn-block">VOLVER</button>
                  </a> 
                </li>

              </ul>

           <?php elseif($ver == "cuentas"): ?> 

              <ul class="nav nav-stacked nav-collapse">
                <li>
                  <a href="<?php echo e(route('usuarios.index')); ?>">
                    <button type="button" class="btn btn-primary btn-lg btn-block">VENTAS</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">MOVIMIENTO</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">CHUEQUES</button>
                  </a> 
                </li>
                <li>
                  <a href="<?php echo e(route('cuenta_corriente.saldo')); ?>">
                    <button type="button" class="btn btn-primary btn-lg btn-block">SALDO</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">BUSQUEDA</button>
                  </a> 
                </li>
                <li>
                  <a href="\\192.168.1.203:8000/">
                    <button type="button" class="btn btn-primary btn-lg btn-block">VOLVER</button>
                  </a> 
                </li>

              </ul>

          <?php elseif(($ver == "saldos")||($ver == "general")): ?> 

              <ul class="nav nav-stacked nav-collapse">
                <li>
                  <a href="<?php echo e(route('cuenta_corriente.general')); ?>">
                    <button type="button" class="btn btn-primary btn-lg btn-block">GENERAL</button>
                  </a> 
                </li>
                <li>
                  <a href="">
                    <button type="button" class="btn btn-primary btn-lg btn-block">CAJA</button>
                  </a> 
                </li>
                <li>
                  <a href="\\192.168.1.203:8000/menu/cuentas/ver/">
                    <button type="button" class="btn btn-primary btn-lg btn-block">VOLVER</button>
                  </a> 
                </li>

              </ul>    



           <?php endif; ?> 

            
