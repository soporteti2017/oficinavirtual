<?php $__env->startSection('titulo', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		<div class="col-md-10">
		 	<div class="panel panel-default">
		 		<div class="panel-heading">
			    	<h3 class="panel-title"><strong><h3>Crear Clientes</h3></strong>
			  	</div>
		        <div class="panel-body">
		        	<?php if(count($errors) > 0): ?>
			  			<div class="alert alert-danger" role="alert">
			  				<ul>
				  				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  					<li> <?php echo e($errores); ?></li>
				  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  				</ul>
			  			</div>	
			  		<?php endif; ?>

<?php echo Form::open(['route' => 'clientes.store', 'method' => 'POST', 'class' => 'form-horizontal']); ?>


<div class="form-group">

	<?php echo Form::label('nombres','Nombres',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('nombres',null, ['class' => 'form-control', 'placeholder'=>'Nombres']); ?>

	</div>

	<?php echo Form::label('rut','Rut',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('rut',null, ['class' => 'form-control', 'placeholder'=>'11.111.111-1','required' ]); ?>

	</div>

	

</div>

<div class="form-group">

	<?php echo Form::label('paterno','Apellido paterno',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('paterno',null, ['class' => 'form-control', 'placeholder' => 'Apellido paterno','required' ]); ?>

	</div>

	<?php echo Form::label('materno','Apellido materno',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('materno',null, ['class' => 'form-control', 'placeholder' => 'Apellido materno','required' ]); ?>

	</div>

</div>


<div class="form-group">

	<?php echo Form::label('nacionalidad','Nacionalidad',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('nacionalidad',null, ['class' => 'form-control', 'placeholder' => 'Chileno','required' ]); ?>

	</div>

	<?php echo Form::label('telefono1','Telefono 1',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('telefono1',null, ['class' => 'form-control', 'placeholder' => '9xxxxxxxx','required' ]); ?>

	</div>

</div>

<div class="form-group">

	<?php echo Form::label('telefono2','Telefono 2',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::text('telefono2',null, ['class' => 'form-control', 'placeholder' => '532xxxxxx']); ?>

	</div>

	<?php echo Form::label('email','E-mail',['class' => 'col-lg-2 control-label']); ?>

	<div class="col-lg-3">
	<?php echo Form::email('email',null, ['class' => 'form-control', 'placeholder' => 'ejemplo@correo.com']); ?>

	</div>

</div>


<br>

<div class="col-lg-1"></div>
<div class="form-group">	

	<?php echo Form::submit('Guardar',['class' => 'btn btn-primary']); ?>

	
</div>

<?php echo Form::close(); ?>

       </div>
		    </div>
		</div>        	



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>