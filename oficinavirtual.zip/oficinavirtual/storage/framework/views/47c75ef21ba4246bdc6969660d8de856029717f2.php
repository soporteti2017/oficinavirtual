<?php $__env->startSection('titulo', 'Estados de conexiones'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">

	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		 <div class="col-md-10">	

		 	<div class="panel panel-default">

<a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-info">Crear cliente</a>

<?php echo Form::open(['route' => 'clientes.index', 'method' => 'GET', 'class' => 'navbar-form pull-right']); ?>


<div class="input-group">
	<?php echo Form::text('name',null,['class' => 'form-control', 'placeholder' => '','aria-describedby' => 'search']); ?>

	<span class="input-group-addon" id="search"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></span>
</div>

<?php echo Form::close(); ?>


<br>
<br>
<table class="table table-striped">
	<thead>
		<th>ID</th>
		<th>Nombres</th>
		<th>Apellido paterno</th>
		<th>Apellido materno</th>
		<th>RUT</th>
		<th>E-mail</th>
		<th>Acción</th>
	</thead>

	<tbody>
		<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
			<td><?php echo e($cliente->id); ?></td>
			<td><?php echo e($cliente->nombres); ?></td>
			<td><?php echo e($cliente->paterno); ?></td>
			<td><?php echo e($cliente->materno); ?></td>
			<td><?php echo e($cliente->rut); ?></td>
			<td><?php echo e($cliente->email); ?></td>
			<td><a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning">Modificar</a> <a href="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" onclick="return confirm(¿Esta seguro de que desea eliminar al cliente?)" class="btn btn-danger">Eliminar</a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php echo $clientes->render(); ?>


		        </div>
		    </div>    	
    	</div>
	</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>