<?php $__env->startSection('titulo', 'Usuarios'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		<div class="col-md-10">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><strong><h3>Editar Tipos de Planes <?php echo $tipo_plan->descripcion; ?></h3></strong>
			  </div>
			  <div class="panel-body">
			    	
			  		<?php echo Form::open(['route' => ['tipos_planes.update', $tipo_plan], 'method' => 'PUT']); ?>

						<div class="form-group">
							<?php echo Form::label('descripcion', 'Descripción'); ?>

							<?php echo Form::text('descripcion', $tipo_plan->descripcion, ['class' => 'form-control', 'placeholder' => 'Ingrese Descripción de serv.', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::label('servicio_id', 'Servicio Asociado'); ?>

							<?php echo Form::select('servicio_id', $servicios, $tipo_plan->servicio->id, ['class' => 'form-control', 
							'placeholder' => 'Seleccione una opción', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::submit('Editar', ['class' => 'btn btn-primary large']);; ?>

						</div>

					<?php echo Form::close(); ?>


			  </div>
			</div>
		</div>	
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>