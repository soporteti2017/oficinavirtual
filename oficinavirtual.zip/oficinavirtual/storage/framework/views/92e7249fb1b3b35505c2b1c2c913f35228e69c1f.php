<?php $__env->startSection('titulo', 'Estados de conexión'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		<div class="col-md-10">
			<div class="panel panel-default">
			  <div class="panel-heading">
			    <h3 class="panel-title"><strong><h3>Editar Estado de conexión  <?php echo $estado_conexion->descripcion; ?></h3></strong>
			  </div>
			  <div class="panel-body">
			    	
			  		<?php echo Form::open(['route' => ['estados_conexiones.update', $estado_conexion], 'method' => 'PUT']); ?>

			
						<div class="form-group">
							<?php echo Form::label('descripcion', 'descripcion'); ?>

							<?php echo Form::text('descripcion', $estado_conexion->descripcion, ['class' => 'form-control', 'placeholder' => 'Ingrese descripción de servicio', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::submit('Editar', ['class' => 'btn btn-primary large']);; ?>

						</div>

					<?php echo Form::close(); ?>


			  </div>
			</div>
		</div>	
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>