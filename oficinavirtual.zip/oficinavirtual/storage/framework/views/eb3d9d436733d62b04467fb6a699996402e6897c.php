<?php $__env->startSection('titulo', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">

	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		 <div class="col-md-10">	

		 	<div class="panel panel-default">

		        <div class="panel-body">
		        		
		        		<div class="panel panel-primary">
							<div class="panel-heading"><strong>Contrato cliente: <?php echo e($nombre_abonado); ?></strong> </div>
								<div class="panel-body">

									<div>

										  <!-- Nav tabs -->
										  <ul class="nav nav-tabs" role="tablist">
										    <li role="presentation" class="active"><a href="#general" aria-controls="general" role="tab" data-toggle="tab">Datos Contrato</a></li>
										    <?php $__currentLoopData = $premiums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premium): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    	<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Servicio Televisión</a></li>
										    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Servicio Premium</a></li>
										    <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Settings</a></li>
										  </ul>

										  <!-- Tab panes -->
										  <div class="tab-content">
										    <div role="tabpanel" class="tab-pane active" id="general">
										    	<br>
										    	<div class="panel panel-primary">
													<div class="panel-heading"><strong>Datos Generales</strong> </div>
														<div class="panel-body">

															<div class="row">
															  <div class="col-md-6">
															  		<form class="form-horizontal">
																	  <div class="form-group">
																	    <label for="inputEmail3" class="col-sm-2 control-label">
																	    	N° Cliente:
																	    </label>
																	    <div class="col-sm-8">
																	      <input type="text" class="form-control" value=" <?php echo e($correlativo_abonado); ?>" disabled>
																	    </div>
																	  </div>
																	</form>  		  	 
															  </div>
															  <div class="col-md-6">
															  	<form class="form-horizontal">
																	  <div class="form-group">
																	    <label for="inputEmail3" class="col-sm-2 control-label">
																	    	Contrato:
																	    </label>
																	    <div class="col-sm-8">
																	      <input type="text" class="form-control" value=" <?php echo e($num_contrato); ?>" disabled>
																	    </div>
																	  </div>
																</form> 
															  </div>
															</div>

															<div class="row">
															  <div class="col-md-4">
															  		<form class="form-horizontal">
																	  <div class="form-group">
																	    <label for="inputEmail3" class="col-sm-2 control-label">
																	    	Fecha Contrato:
																	    </label>
																	    <div class="col-sm-8">
																	      <input type="text" class="form-control" value=" <?php echo e($fecha_contrato); ?>" disabled>
																	    </div>
																	  </div>
																	</form>  		  	 
															  </div>
															  <div class="col-md-4">
															  	<form class="form-horizontal">
																	  <div class="form-group">
																	    <label for="inputEmail3" class="col-sm-2 control-label">
																	    	Estado:
																	    </label>
																	    <div class="col-sm-8">
																	      <input type="text" class="form-control" value=" <?php echo e($estado_cone); ?>" disabled>
																	    </div>
																	  </div>
																</form> 
															  </div>
															  <div class="col-md-4">
															  	<form class="form-horizontal">
																	  <div class="form-group">
																	    <label for="inputEmail3" class="col-sm-2 control-label">
																	    	Estado:
																	    </label>
																	    <div class="col-sm-8">
																	      <input type="text" class="form-control" value=" <?php echo e($fecha_estado); ?>" disabled>
																	    </div>
																	  </div>
																</form> 
															  </div>
															</div>

														</div>
												</div>

												<br>
										    	<div class="panel panel-primary">
													<div class="panel-heading"><strong>Tarifas</strong> </div>
														<div class="panel-body">

														</div>
												</div>			

										    </div>
										    <div role="tabpanel" class="tab-pane" id="profile"></div>
										    <div role="tabpanel" class="tab-pane" id="messages">
										    	<br>
										    	<?php $__currentLoopData = $premiums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $premium): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										    		<div class="panel panel-primary">
													<div class="panel-heading"><strong>Instalación Decodificador</strong> </div>
														<div class="panel-body">
															<div class="row">
																<div class="col-md-6">
																  	<form class="form-horizontal">
																		  <div class="form-group">
																		    <label for="inputEmail3" class="col-sm-4 control-label">
																		    	Numero decodificador:
																		    </label>
																		    <div class="col-sm-5">
																		      <input type="text" class="form-control" value=" <?php echo e($premium->serie); ?>" disabled>
																		    </div>
																		  </div>
																	</form> 
																 </div>
																 <div class="col-md-6">
																 </div>	
															</div>	
															<div class="row"> 
																 <div class="col-md-6">
																  	<form class="form-horizontal">
																		  <div class="form-group">
																		    <label for="inputEmail3" class="col-sm-4 control-label">
																		    	Fecha Instalación:
																		    </label>
																		    <div class="col-sm-5">
																		      <input type="text" class="form-control" value=" <?php echo e($premium->fecha); ?>" disabled>
																		    </div>
																		  </div>
																	</form> 
																 </div>
																 <div class="col-md-6">
																 </div>	
															</div>	
															<div class="row"> 
																 <div class="col-md-6">
																  	<form class="form-horizontal">
																		  <div class="form-group">
																		    <label for="inputEmail3" class="col-sm-4 control-label">
																		    	OT:
																		    </label>
																		    <div class="col-sm-5">
																		      <input type="text" class="form-control" value=" " disabled>
																		    </div>
																		  </div>
																	</form> 
																 </div>
																 <div class="col-md-6">
																 </div>	
															</div> 
															<div class="row"> 
																 <div class="col-md-6">
																  	<form class="form-horizontal">
																		  <div class="form-group">
																		    <label for="inputEmail3" class="col-sm-4 control-label">
																		    	Estado Decofificador:
																		    </label>
																		    <div class="col-sm-5">
																		      <input type="text" class="form-control" value=" <?php echo e($premium->alta); ?>" disabled>
																		    </div>
																		  </div>
																	</form> 
																 </div>
																 <div class="col-md-6">
																 </div>	
															</div>
														</div>
													</div>		
													<br>
													<div class="panel panel-primary">
													<div class="panel-heading"><strong>Señales y tarifas</strong> </div>
														<div class="panel-body">
															<div class="row">
																<div class="col-md-6">
																  	<form class="form-horizontal">
																		  <div class="form-group">
																		    <label for="inputEmail3" class="col-sm-4 control-label">
																		    	Numero decodificador:
																		    </label>
																		    <div class="col-sm-5">
																		      <input type="text" class="form-control" value=" <?php echo e($premium->serie); ?>" disabled>
																		    </div>
																		  </div>
																	</form> 
																 </div>
																 <div class="col-md-6">
																 </div>	
															</div>

														</div>
													</div>
													</div>				
										    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										    </div>
										    <div role="tabpanel" class="tab-pane" id="settings">

										    </div>
										  </div>

									</div>

								</div>
						</div>			
						    
		        </div>
		    </div>    	
    	</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>