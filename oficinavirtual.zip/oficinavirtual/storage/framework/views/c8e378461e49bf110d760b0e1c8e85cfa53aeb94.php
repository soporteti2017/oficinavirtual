<?php $__env->startSection('titulo', 'Tipos de Planes'); ?>

<?php $__env->startSection('content'); ?>

	<div class="row">
	    <div class="col-md-2">
	        <div class="panel panel-default">

		        <div class="panel-body">
		        	<div class="panel panel-default" id="sidebar" >
			            <div class="panel-heading" style="background-color:#207ce5;color:#fff;" data-target="#test"><?php echo $__env->yieldContent('titulo'); ?>  | OficinaVirtual</div> 
			            	<div class="panel-body" id="test">
			            		<?php echo $__env->make('intranet/template/partials/nav-vertical', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			            	</div>	
			        </div>		
			    </div>    
		    </div>
		</div>
		<div class="col-md-10">
		 	<div class="panel panel-default">
		 		<div class="panel-heading">
			    	<h3 class="panel-title"><strong><h3>Crear Tipos de Planes</h3></strong>
			  	</div>
		        <div class="panel-body">
		        	<?php if(count($errors) > 0): ?>
			  			<div class="alert alert-danger" role="alert">
			  				<ul>
				  				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errores): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  					<li> <?php echo e($errores); ?></li>
				  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  				</ul>
			  			</div>	
			  		<?php endif; ?>


			  		<?php echo Form::open(['route' => 'tipos_planes.store', 'method' => 'POST']); ?>

			
						<div class="form-group">
							<?php echo Form::label('descripcion', 'Descripción'); ?>

							<?php echo Form::text('descripcion', null, ['class' => 'form-control', 'placeholder' => 'Ingrese Descripción de serv.', 'required']); ?>

						</div>


						<div class="form-group">
							<?php echo Form::label('servicio_id', 'Servicio Asociado'); ?>

							<?php echo Form::select('servicio_id', $servicios, null, ['class' => 'form-control', 
							'placeholder' => 'Seleccione una opción', 'required']); ?>

						</div>

						<div class="form-group">
							<?php echo Form::submit('Ingresar', ['class' => 'btn btn-primary large']);; ?>

						</div>

					<?php echo Form::close(); ?>

		        </div>
		    </div>
		</div>        	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>