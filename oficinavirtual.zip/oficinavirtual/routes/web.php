<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('intranet.template.main');
// });

Route::group(['prefix' => 'usuarios'], function(){

	Route::get('view/{id}', [
		'uses'	=> 'UsuarioControlador@view',
		'as'	=> 'usuarios'
		]);

});

Route::group(['prefix' => 'intranet'], function(){
	Route::resource('usuarios', 'UsuarioControlador');
	Route::get('usuarios/{id}/destroy', [
		'uses' 	=> 'UsuarioControlador@destroy',
		'as'	=> 'usuarios.destroy'
		]);

	Route::resource('servicios', 'ServicioControlador');
	Route::get('servicios/{id}/destroy', [
		'uses'	=> 'ServicioControlador@destroy',
		'as'	=> 'servicios.destroy'
		]);
	Route::resource('tipos_planes', 'TiposPlanesControlador');
	Route::get('tipos_planes/{id}/destroy', [
		'uses'	=> 'TiposPlanesControlador@destroy',
		'as'	=> 'tipos_planes.destroy'
		]);

	Route::resource('planes', 'PlanesControlador');
	Route::get('planes/{id}/destroy', [
		'uses'	=> 'PlanesControlador@destroy',
		'as'	=> 'planes.destroy'
		]);

	Route::resource('estados_conexiones', 'EstadoConexionControlador');
	Route::get('estados_conexiones/{id}/destroy', [
		'uses'	=> 'EstadoConexionControlador@destroy',
		'as'	=> 'estados_conexiones.destroy'
		]);
	Route::resource('clientes', 'ClientesControlador');
	Route::get('clientes/{id}/destroy',
	['uses' => 'ClientesControlador@destroy',
	'as' => 'clientes.destroy']
	);
	Route::resource('formas_pagos', 'FormaPagoControlador');

	Route::resource('tipos_pagos', 'TipoPagoControlador');
	Route::get('tipos_pagos/{id}/destroy',
	['uses' => 'TipoPagoControlador@destroy',
	'as' => 'tipos_pagos.destroy']
	);
	Route::resource('movimientos_ctacte', 'MovimientoctacteControlador');

	Route::get('cuenta_corriente/saldo', [
		'uses'	=> 'CuentaCorrienteControlador@index',
		'as'	=> 'cuenta_corriente.saldo'
		]);
	Route::get('cuenta_corriente/general', [
		'uses'	=> 'CuentaCorrienteControlador@general',
		'as'	=> 'cuenta_corriente.general'
		]);

	Route::post('cuenta_corriente/consulta', [
		'uses'	=> 'CuentaCorrienteControlador@consulta',
		'as'	=> 'cuenta_corriente.consulta'
		]);
	Route::get('cuenta_corriente/vercontrato', [
		'uses'	=> 'CuentaCorrienteControlador@general',
		'as'	=> 'cuenta_corriente.vercontrato'
		]);
	Route::post('cuenta_corriente/verdetalles', [
		'uses'	=> 'CuentaCorrienteControlador@verdetalles',
		'as'	=> 'cuenta_corriente.verdetalles'
		]);



});


Auth::routes(); 

Route::get('/', 'HomeController@index');

Route::get('index', 'HomeController@inicio');

Route::group(['prefix' => 'menu'], function(){
	Route::get('usuarios/ver', [
		'uses' 	=> 'HomeController@verMenuUsuario',
		'as'	=> 'usuarios.menu'
		]);
	Route::get('clientes/ver', [
		'uses' 	=> 'HomeController@verMenuCliente',
		'as'	=> 'clientes.menu'
		]);
	Route::get('cuentas/ver', [
		'uses' 	=> 'HomeController@verMenuCuenta',
		'as'	=> 'cuentas.menu'
		]);
});